const ADDITION = 'addition';
const SUBTRACTION = 'subtraction';
const MULTIPLICATION = 'multiplication';
const DIVISION = 'division';

module.exports = {
  ADDITION,
  SUBTRACTION,
  MULTIPLICATION,
  DIVISION,
};
